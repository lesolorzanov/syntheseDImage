modified nvWidgets
mailto:jean-claude.iehl@liris.cnrs.fr

original code :
http://code.google.com/p/nvidia-widgets/

refactored version :
	- uses SDL2
	- widgets rendering using openGL 3.3 core profile
	- font rendering using SDL2_ttf / FreeType 2
	
